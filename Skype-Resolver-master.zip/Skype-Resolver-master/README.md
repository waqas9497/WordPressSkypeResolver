Sky-Resolver
============

Get someone's IP address through their skype ID
